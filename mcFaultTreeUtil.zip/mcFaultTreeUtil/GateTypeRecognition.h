#include "GateStrategy.h"

class GateTypeRecognition
{
public:
	GateTypeRecognition(GateTypes& const type);
	~GateTypeRecognition();
	bool GetResult(Tree& const node);
private:
	GateStrategy* gateStrategy = nullptr;
};
