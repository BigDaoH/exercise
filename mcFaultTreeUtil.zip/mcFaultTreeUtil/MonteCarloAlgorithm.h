#include "GateTypeRecognition.h"

class MonteCarloAlgorithm
{
public:
	MonteCarloAlgorithm(Tree& tree, unsigned long long mcSumCount);
	float GetValue();
private:
	float result;
	double *dDamagedDecideRandom;
	unsigned long long damagedNum = 0;
	void ResultCount(Tree& tree);
	bool SingleCount(Tree& node, int numLeaf);
};