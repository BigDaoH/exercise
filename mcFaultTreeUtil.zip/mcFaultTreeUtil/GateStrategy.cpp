#include "GateStrategy.h"

bool ANDGate::bEventIsUnDamaged(Tree& const node)
{
	for (Tree item : node.children)
	{
		if (!item.bUnDamaged)
		{
			return false;
		}
	}
	return true;
}

bool ORGate::bEventIsUnDamaged(Tree& const node)
{
	for (Tree item : node.children)
	{
		if (item.bUnDamaged)
		{
			return true;
		}
	}
	return false;
}
