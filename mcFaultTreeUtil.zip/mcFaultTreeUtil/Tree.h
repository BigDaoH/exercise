#include <list>
using namespace std;

enum GateTypes { AND, OR };
class Tree
{
public:
	unsigned int iSumLeaf;
	list<Tree> children;
	float fProbability;
	GateTypes gateType;
	bool bDamaged;
	bool bIsLeaf();
};
