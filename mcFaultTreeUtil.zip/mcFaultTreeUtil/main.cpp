#include <iostream>
#include "MonteCarloAlgorithm.h"

int main()
{
	Tree faultTree;
	Tree node;
	node.fProbability = 0.2;
	faultTree.children.push_back(node);
	faultTree.children.push_back(node);
	faultTree.iSumLeaf = 2;
	faultTree.gateType = OR;
	 
	MonteCarloAlgorithm count(faultTree, 10000000);
	cout << count.GetValue();
	system("pause");
	return 0;
}