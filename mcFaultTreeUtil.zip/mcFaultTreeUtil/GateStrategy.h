#include "Tree.h"

class GateStrategy
{
public:
	virtual bool bEventIsDamaged(Tree& const node) = 0;
};

class ANDGate :public GateStrategy
{
public:
	bool bEventIsDamaged(Tree& const node);
};

class ORGate :public GateStrategy
{
public:
	bool bEventIsDamaged(Tree& const node);
};

