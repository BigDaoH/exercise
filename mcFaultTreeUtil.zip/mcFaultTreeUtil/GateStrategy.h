#include "Tree.h"

class GateStrategy
{
public:
	virtual bool bEventIsUnDamaged(Tree& const node) = 0;
};

class ANDGate :public GateStrategy
{
public:
	bool bEventIsUnDamaged(Tree& const node);
};

class ORGate :public GateStrategy
{
public:
	bool bEventIsUnDamaged(Tree& const node);
};

