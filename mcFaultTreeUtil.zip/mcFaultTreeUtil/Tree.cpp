#include "Tree.h"

bool Tree::bIsLeaf()
{
	return 0 == this->children.size();
}
