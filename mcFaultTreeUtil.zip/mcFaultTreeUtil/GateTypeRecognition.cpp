#include "GateTypeRecognition.h"

GateTypeRecognition::GateTypeRecognition(GateTypes & const type)
{
	switch (type)
	{
	case AND:
		this->gateStrategy = new ANDGate();
		break;
	case OR:
		this->gateStrategy = new ORGate();
		break;
	default:
		break;
	}
}

GateTypeRecognition::~GateTypeRecognition()
{
	delete gateStrategy;
}

bool GateTypeRecognition::GetResult(Tree& const node)
{
	return gateStrategy->bEventIsDamaged(node);
}
